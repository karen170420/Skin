# Skin by Lipstickk: guía para publicar en Vercel

## Qué contiene
- `index.html`: tu página (mismo diseño, secciones, diagnóstico, rutinas, Mis resultados, escáner facial y chat).
- `api/chat.js` y `api/scan.js`: funciones del servidor para el chat y el escáner. Acá vive la clave de la API.
- `api/_lib.js`, `vercel.json`, `package.json`: configuración.

## Estructura de archivos (dónde va cada uno)
```
skin-by-lipstickk/          <- carpeta raíz del repositorio
├── index.html              <- toda la página (diseño, diagnóstico, escáner, chat)
├── vercel.json             <- configuración de Vercel (tiempo de las funciones, permiso de cámara)
├── package.json            <- datos del proyecto (sin dependencias)
├── .env.example            <- modelo de variables de entorno (sin claves reales)
├── .gitignore              <- evita subir claves por error
└── api/                    <- la carpeta debe llamarse exactamente "api"
    ├── chat.js             <- servidor del chat
    ├── scan.js             <- servidor del escáner facial
    └── _lib.js             <- código compartido (límites y llamada a la API)
```

## Dependencias
Ninguna. No hace falta `npm install`: las funciones usan solo Node 18 o superior, que Vercel ya incluye.

## Probarla en tu computadora (opcional)
1. Instalá Node.js 18 o superior (nodejs.org).
2. Copiá `.env.example` a un archivo nuevo llamado `.env.local` y reemplazá el texto por tu clave real. Ese archivo no se sube a GitHub.
3. En la carpeta del proyecto ejecutá `npx vercel dev` y abrí la dirección que muestra (normalmente http://localhost:3000).

## Publicar paso a paso (sin instalar nada)
1. Creá una cuenta gratis en **github.com** y un repositorio nuevo (por ejemplo `skin-by-lipstickk`).
2. Subí todos los archivos de esta carpeta (botón *Add file → Upload files*), manteniendo la carpeta `api`. Confirmá con *Commit*.
3. Creá una cuenta gratis en **vercel.com** (podés entrar con GitHub).
4. En Vercel: *Add New → Project*, elegí tu repositorio y tocá *Deploy*. No cambies nada de la configuración.
5. Conseguí la clave de la API: entrá a **platform.claude.com**, creá una cuenta, cargá crédito (*Billing*) y generá una clave en *API keys*.
6. En Vercel: tu proyecto → *Settings → Environment Variables*. Agregá `ANTHROPIC_API_KEY` con tu clave (marcá todos los entornos) y guardá.
7. Andá a *Deployments*, abrí el menú (⋯) del último y elegí *Redeploy*, para que tome la clave.
8. Tu enlace público queda en *Domains* (algo como `skin-by-lipstickk.vercel.app`). Es permanente y funciona en celular y computadora, sin cuenta de nadie.
9. Opcional: en *Settings → Domains* podés conectar un dominio propio.

## Costos aproximados (precios de lista, verificá en platform.claude.com)
| Función | Modelo | Precio por millón de tokens | Costo aprox. |
|---|---|---|---|
| Chat | Haiku 5.5 | USD 0,10 entrada / 0,50 salida | menos de USD 0,001 por mensaje |
| Escáner | Sonnet 5.5 | USD 2 entrada / 10 salida | cerca de USD 0,01 a 0,03 por foto |

- Con 1.000 escaneos al mes serían unos USD 10 a 30. El chat casi no suma.
- Para gastar menos, poné `SCAN_MODEL=claude-haiku-5-5` en las variables de entorno (más barato, con algo menos de calidad).
- Vercel es gratis para este uso (plan Hobby, uso personal/no comercial). Si la tienda genera ventas por la página, revisá si te corresponde el plan Pro.
- **Importante:** en platform.claude.com poné un **límite de gasto mensual** para que nunca te sorprenda una factura.

## Seguridad y privacidad
- La clave solo está en el servidor de Vercel; el navegador nunca la ve.
- El servidor limita las consultas por persona (40 chats y 10 escaneos por hora, de forma aproximada), valida los datos y fija el rol del asistente, para que nadie use tu clave como un chat general.
- La foto se reduce en el celular, se envía a la API solo para el análisis y no se guarda. Los resultados se guardan únicamente en el dispositivo de cada persona (localStorage).

## Qué funciona sin servicios externos y qué no
| Función | Sin Claude/cuenta | Necesita |
|---|---|---|
| Diagnóstico y rutinas | Sí, corre en el navegador | Nada |
| Mis resultados | Sí, guardado en el dispositivo | Nada |
| Preguntas frecuentes, enlace a la tienda | Sí | Nada |
| Cámara / subir foto | Sí (cámara requiere permiso y https, que Vercel da) | Nada |
| Chat | Sí para el usuario | Clave API de Anthropic en el servidor |
| Análisis facial | Sí para el usuario | Clave API de Anthropic en el servidor |

## Pendiente de tu parte
- **Opiniones** y **Consejos saludables**: no existían en la versión que construimos (no tengo los testimonios y no quiero inventarlos). Pasame los textos y los sumo.
- Los productos del escáner enlazan a la portada de tu tienda. Con los links de cada producto se puede enlazar uno por uno.
- El historial no se sincroniza entre dispositivos (no hay cuentas de usuario).
