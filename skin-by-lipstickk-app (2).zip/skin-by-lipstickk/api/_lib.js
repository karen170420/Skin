const hits = new Map();
exports.limited = (req, max) => {
  const ip = String(req.headers["x-forwarded-for"] || "x").split(",")[0].trim();
  const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 3600e3);
  if (a.length >= max) return true;
  a.push(now); hits.set(ip, a);
  if (hits.size > 5000) hits.clear();
  return false;
};
exports.askClaude = async (body) => {
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
    body: JSON.stringify(body),
  });
  if (!r.ok) { console.error("Anthropic API", r.status, (await r.text()).slice(0, 300)); throw new Error("upstream " + r.status); }
  const j = await r.json();
  return (j.content || []).filter(b => b.type === "text").map(b => b.text).join("");
};
